package FindLocation;

public enum UserScales {
	CrimeRate,
	AvgSal,
	CostOfLiving
	
}
