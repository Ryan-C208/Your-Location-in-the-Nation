package UserModel;

public class PopularLocations {
	public String Zipcode;
	public int NumberOfSaves;
	
	
	
	public PopularLocations() {
		
	}



	public String getZipcode() {
		return Zipcode;
	}



	public void setZipcode(String zipcode) {
		Zipcode = zipcode;
	}



	public int getNumberOfSaves() {
		return NumberOfSaves;
	}



	public void setNumberOfSaves(int numberOfSaves) {
		NumberOfSaves = numberOfSaves;
	}
	
	
	
}
