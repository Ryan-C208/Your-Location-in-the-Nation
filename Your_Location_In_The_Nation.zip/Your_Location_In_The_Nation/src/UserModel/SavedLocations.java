package UserModel;

public class SavedLocations {
	private String Username;
	private String Zipcode;
	
	public SavedLocations() {
		
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getZipcode() {
		return Zipcode;
	}
	public void setZipcode(String zipcode) {
		Zipcode = zipcode;
	}
}
