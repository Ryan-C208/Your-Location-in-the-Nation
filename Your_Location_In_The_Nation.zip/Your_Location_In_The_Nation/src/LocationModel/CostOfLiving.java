package LocationModel;

public class CostOfLiving {
	private int Scale;
	private float CostOfLivingIndex;
	
	public CostOfLiving() {
		
	}
	
	public int getScale() {
		return Scale;
	}
	public void setScale(int scale) {
		Scale = scale;
	}
	public float getCostOfLivingIndex() {
		return CostOfLivingIndex;
	}
	public void setCostOfLivingIndex(float costOfLivingIndex) {
		CostOfLivingIndex = costOfLivingIndex;
	}
}
