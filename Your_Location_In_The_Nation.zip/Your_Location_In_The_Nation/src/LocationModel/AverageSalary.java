package LocationModel;

public class AverageSalary {
	private int Scale;
	private int AvgSalaryPerHousehold;
	
	
	public AverageSalary() {
		
	}
	
	
	public int getScale() {
		return Scale;
	}
	public void setScale(int scale) {
		Scale = scale;
	}
	public int getAvgSalaryPerHousehold() {
		return AvgSalaryPerHousehold;
	}
	public void setAvgSalaryPerHousehold(int avgSalaryPerHousehold) {
		AvgSalaryPerHousehold = avgSalaryPerHousehold;
	}
	
	
}
