package LocationModel;

public class CrimeRate {
	private int Scale;
	private int RatePerHundredThousand;
	
	public CrimeRate() {
		
	}
	
	public int getScale() {
		return Scale;
	}
	public void setScale(int scale) {
		Scale = scale;
	}
	public int getRatePerHundredThousand() {
		return RatePerHundredThousand;
	}
	public void setRatePerHundredThousand(int ratePerHundredThousand) {
		RatePerHundredThousand = ratePerHundredThousand;
	}
}
